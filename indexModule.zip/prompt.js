var Prompt = {
  GREETING: 'Hi, this is faceBook Messenger helper, I can help you to send, check or receive message from facebook messenger'
}

exports.Prompt = Prompt;
